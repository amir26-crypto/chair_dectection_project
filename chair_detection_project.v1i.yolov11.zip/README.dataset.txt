# chair_detection_project > 2025-01-29 8:20pm
https://universe.roboflow.com/amir-co7mw/chair_detection_project

Provided by a Roboflow user
License: CC BY 4.0

